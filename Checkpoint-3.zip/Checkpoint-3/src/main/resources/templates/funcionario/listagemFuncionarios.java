<table>
    <tr>
        <th>ID</th>
        <th>Nome</th>
        <th>Cargo</th>
    </tr>
    <%-- Iteração sobre a lista de funcionários --%>
</table>
